import { useMemo, useState } from "react";
import { toast } from "sonner";
import {
  Activity,
  ArrowDownRight,
  ArrowUpRight,
  BarChart3,
  Bell,
  BookOpen,
  Bot,
  BriefcaseBusiness,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  CircleAlert,
  Clock3,
  Command,
  FileText,
  Flame,
  Headphones,
  Inbox,
  LayoutDashboard,
  LifeBuoy,
  ListFilter,
  LockKeyhole,
  Menu,
  MessageSquareText,
  MoreHorizontal,
  Network,
  Play,
  Plus,
  Radar,
  Search,
  ShieldCheck,
  Sparkles,
  Ticket,
  UserRound,
  Wrench,
  X,
  Zap,
} from "lucide-react";

type StatusTone = "critical" | "warning" | "healthy" | "neutral";

type Incident = {
  id: string;
  title: string;
  service: string;
  assignee: string;
  initials: string;
  priority: "P1" | "P2" | "P3";
  state: string;
  sla: number;
  tone: StatusTone;
  time: string;
};

const navItems = [
  { label: "Overview", icon: LayoutDashboard },
  { label: "Incidents", icon: Ticket, count: "42" },
  { label: "Requests", icon: Inbox, count: "18" },
  { label: "Knowledge", icon: BookOpen },
];

const incidents: Incident[] = [
  {
    id: "INC0010042",
    title: "Checkout API returning 502s in EU region",
    service: "Payments / Checkout",
    assignee: "N. Patel",
    initials: "NP",
    priority: "P1",
    state: "In progress",
    sla: 82,
    tone: "critical",
    time: "8m ago",
  },
  {
    id: "INC0010038",
    title: "VPN authentication degraded for contractors",
    service: "Identity & Access",
    assignee: "M. Chen",
    initials: "MC",
    priority: "P2",
    state: "Investigating",
    sla: 61,
    tone: "warning",
    time: "24m ago",
  },
  {
    id: "INC0010029",
    title: "Warehouse scanner fleet offline in Rotterdam",
    service: "Fulfilment / Devices",
    assignee: "A. Singh",
    initials: "AS",
    priority: "P2",
    state: "Awaiting vendor",
    sla: 44,
    tone: "warning",
    time: "41m ago",
  },
  {
    id: "INC0010017",
    title: "Payroll export missing cost-centre mapping",
    service: "People / Payroll",
    assignee: "J. Adams",
    initials: "JA",
    priority: "P3",
    state: "Pending user",
    sla: 19,
    tone: "healthy",
    time: "1h ago",
  },
];

const queueBars = [46, 58, 41, 63, 56, 75, 68, 83, 72, 88, 64, 78, 86, 67, 93, 76, 81, 70];

function StatusDot({ tone }: { tone: StatusTone }) {
  return <span className={`status-dot ${tone}`} aria-hidden="true" />;
}

function Avatar({ initials, tone = "mint" }: { initials: string; tone?: "mint" | "amber" | "violet" }) {
  return <span className={`avatar avatar-${tone}`}>{initials}</span>;
}

function MetricCard({
  label,
  value,
  detail,
  trend,
  trendUp = true,
  icon: Icon,
  tone,
  bars,
}: {
  label: string;
  value: string;
  detail: string;
  trend: string;
  trendUp?: boolean;
  icon: typeof Activity;
  tone: "mint" | "amber" | "blue" | "violet";
  bars: number[];
}) {
  return (
    <div className="metric-card">
      <div className="metric-topline">
        <div className={`metric-icon ${tone}`}><Icon size={17} strokeWidth={2.2} /></div>
        <span className={`trend ${trendUp ? "up" : "down"}`}>
          {trendUp ? <ArrowUpRight size={13} /> : <ArrowDownRight size={13} />}
          {trend}
        </span>
      </div>
      <div className="metric-label">{label}</div>
      <div className="metric-value">{value}</div>
      <div className="metric-bottom">
        <span>{detail}</span>
        <div className="mini-bars" aria-hidden="true">
          {bars.map((bar, index) => <span key={index} style={{ height: `${bar}%` }} />)}
        </div>
      </div>
    </div>
  );
}

function IncidentRow({
  incident,
  selected,
  onSelect,
}: {
  incident: Incident;
  selected: boolean;
  onSelect: () => void;
}) {
  return (
    <button className={`incident-row ${selected ? "selected" : ""}`} onClick={onSelect}>
      <div className="incident-main">
        <div className="incident-id"><StatusDot tone={incident.tone} />{incident.id}</div>
        <div className="incident-title">{incident.title}</div>
        <div className="incident-meta"><span>{incident.service}</span><span className="meta-separator">·</span><span>{incident.time}</span></div>
      </div>
      <div className="incident-owner"><Avatar initials={incident.initials} /><span>{incident.assignee}</span></div>
      <div className={`priority ${incident.priority.toLowerCase()}`}>{incident.priority}</div>
      <div className="incident-state"><span>{incident.state}</span><ChevronRight size={16} /></div>
    </button>
  );
}

export default function Home() {
  const [activeSection, setActiveSection] = useState("Overview");
  const [selectedId, setSelectedId] = useState("INC0010042");
  const [scenarioMode, setScenarioMode] = useState(false);
  const [showNotes, setShowNotes] = useState(false);
  const [query, setQuery] = useState("");
  const [commandOpen, setCommandOpen] = useState(false);

  const selectedIncident = incidents.find((incident) => incident.id === selectedId) ?? incidents[0];
  const filteredIncidents = useMemo(
    () => incidents.filter((incident) => `${incident.id} ${incident.title} ${incident.service}`.toLowerCase().includes(query.toLowerCase())),
    [query],
  );

  const activateNav = (label: string) => {
    setActiveSection(label);
    if (label !== "Overview") toast(`${label} workspace selected`, { description: "This portfolio simulator keeps the control plane in one view for fast triage." });
  };

  const runScenario = () => {
    setScenarioMode((current) => !current);
    toast.success(scenarioMode ? "Scenario mode closed" : "Scenario mode active", {
      description: scenarioMode ? "Returning to normal queue health." : "P1 incident signals are now elevated for demo review.",
    });
  };

  const promoteIncident = () => {
    toast.success("Major incident workflow triggered", {
      description: "Bridge channel created · Stakeholders notified · Runbook attached",
    });
  };

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand-lockup">
          <div className="brand-mark"><span /><span /><span /></div>
          <div><div className="brand-name">OPS STUDIO</div><div className="brand-sub">ServiceNow portfolio lab</div></div>
        </div>

        <div className="workspace-switcher">
          <div className="workspace-avatar">AC</div>
          <div className="workspace-copy"><strong>Acme Cloud</strong><span>IT Operations</span></div>
          <ChevronDown size={15} />
        </div>

        <div className="rail-label">WORKSPACE</div>
        <nav className="nav-list" aria-label="Primary navigation">
          {navItems.map(({ label, icon: Icon, count }) => (
            <button key={label} className={`nav-item ${activeSection === label ? "active" : ""}`} onClick={() => activateNav(label)}>
              <Icon size={17} strokeWidth={activeSection === label ? 2.5 : 1.9} />
              <span>{label}</span>
              {count && <span className="nav-count">{count}</span>}
            </button>
          ))}
        </nav>

        <div className="rail-label rail-spacer">OPERATIONS</div>
        <nav className="nav-list">
          <button className="nav-item" onClick={() => toast("Reporting view is ready", { description: "The live KPI layer is available in the dashboard canvas." })}><BarChart3 size={17} /><span>Performance</span></button>
          <button className="nav-item" onClick={() => toast("Automation catalog opened", { description: "Flow Designer and assignment rules are represented in the implementation notes." })}><Bot size={17} /><span>Automations</span><span className="new-pill">NEW</span></button>
          <button className="nav-item" onClick={() => toast("CMDB relationship map queued", { description: "Configuration item mapping is a planned v2 extension." })}><Network size={17} /><span>CMDB map</span></button>
        </nav>

        <div className="sidebar-bottom">
          <div className="portfolio-card">
            <div className="portfolio-card-top"><Sparkles size={15} /><span>PORTFOLIO MODE</span></div>
            <strong>Show the thinking, not just the screen.</strong>
            <p>Every panel maps to a real ITSM decision or platform capability.</p>
            <button onClick={() => setShowNotes(true)}>View implementation notes <ArrowUpRight size={14} /></button>
          </div>
          <div className="profile-row"><Avatar initials="RK" tone="violet" /><div><strong>Ravi Kumar</strong><span>Platform builder</span></div><MoreHorizontal size={16} /></div>
        </div>
      </aside>

      <main className="main-canvas">
        <header className="topbar">
          <div className="breadcrumb"><span>Service Operations</span><ChevronRight size={14} /><strong>{activeSection}</strong></div>
          <div className="topbar-actions">
            <button className="command-trigger" onClick={() => setCommandOpen(true)}><Search size={15} /><span>Search anything</span><kbd>⌘ K</kbd></button>
            <button className="icon-button" onClick={() => toast("No new alerts", { description: "All priority-one notifications are acknowledged." })} aria-label="Notifications"><Bell size={17} /><span className="notification-dot" /></button>
            <button className="help-button" onClick={() => toast("Ops Studio demo guide", { description: "Start with the selected P1 incident, then run the scenario to see the control loop." })}><LifeBuoy size={16} />Guide</button>
          </div>
        </header>

        <div className="content-wrap">
          <section className="hero-panel" style={{ backgroundImage: "url('/manus-storage/ops-studio-grid_e9f0a670.png')" }}>
            <div className="hero-overlay" />
            <div className="hero-content">
              <div className="eyebrow"><span className="eyebrow-pulse" />Q3 2026 · ITSM CONTROL PLANE</div>
              <h1>Turn noisy tickets<br /><em>into clear next actions.</em></h1>
              <p>A high-signal operations console for incident triage, SLA protection, and service reliability. Built to show how a ServiceNow platform thinker connects workflow to outcomes.</p>
              <div className="hero-actions">
                <button className={`primary-button ${scenarioMode ? "active-scenario" : ""}`} onClick={runScenario}>{scenarioMode ? <Check size={16} /> : <Play size={15} fill="currentColor" />}{scenarioMode ? "Scenario running" : "Run live scenario"}</button>
                <button className="ghost-button" onClick={() => setShowNotes(true)}>Open case study <ArrowUpRight size={15} /></button>
              </div>
            </div>
            <div className="hero-aside">
              <div className="hero-aside-label">SYSTEM PULSE</div>
              <div className="pulse-ring"><div className="pulse-core"><span>98.6</span><small>%</small></div></div>
              <div className="pulse-caption"><span className="healthy-line" />All core services healthy</div>
              <div className="hero-aside-foot"><span>Last sync</span><strong>14 seconds ago</strong></div>
            </div>
          </section>

          <section className="metrics-grid" aria-label="Service operations metrics">
            <MetricCard label="Open incidents" value={scenarioMode ? "43" : "42"} detail="vs 48 last week" trend="12.5%" icon={Ticket} tone="mint" bars={[35, 46, 42, 58, 52, 67, 60, 72, 70, 82]} />
            <MetricCard label="First response" value="14m" detail="target < 20m" trend="18.2%" icon={Clock3} tone="blue" bars={[72, 66, 74, 62, 58, 54, 51, 46, 42, 38]} />
            <MetricCard label="SLA at risk" value={scenarioMode ? "4" : "3"} detail="needs attention now" trend="1 new" trendUp={false} icon={Flame} tone="amber" bars={[30, 40, 36, 51, 45, 57, 64, 60, 73, 78]} />
            <MetricCard label="Self-service deflection" value="31%" detail="+6 pts this month" trend="6.4%" icon={ShieldCheck} tone="violet" bars={[29, 38, 35, 45, 51, 57, 60, 68, 73, 81]} />
          </section>

          <section className="work-grid">
            <div className="queue-card panel-card">
              <div className="panel-heading">
                <div><div className="section-kicker">SERVICE HEALTH</div><h2>Queue health</h2></div>
                <button className="more-button" onClick={() => toast("Queue filters", { description: "Showing the last 24 hours across all business services." })}><ListFilter size={16} /> Filter</button>
              </div>
              <div className="queue-summary"><div><strong>{scenarioMode ? "4" : "3"}</strong><span>priority items</span></div><div><strong>84%</strong><span>within SLA</span></div><div><strong>2.4h</strong><span>median resolve</span></div></div>
              <div className="chart-area">
                <div className="chart-y-axis"><span>100</span><span>75</span><span>50</span><span>25</span><span>0</span></div>
                <div className="bar-chart">{queueBars.map((height, index) => <div className="bar-column" key={index}><span className={`bar ${index > 13 ? "bar-warm" : ""}`} style={{ height: `${scenarioMode && index > 14 ? height + 6 : height}%` }} /></div>)}</div>
              </div>
              <div className="chart-footer"><span><i className="legend-dot mint" />Resolved</span><span><i className="legend-dot warm" />At risk</span><span className="chart-period">Last 24 hours <ChevronDown size={14} /></span></div>
            </div>

            <div className="watchlist-card panel-card">
              <div className="panel-heading">
                <div><div className="section-kicker">RESPONSE PRIORITY</div><h2>SLA watchlist <span className="live-badge"><span />LIVE</span></h2></div>
                <button className="more-button icon-only" onClick={() => toast("Watchlist exported", { description: "CSV export prepared for the incident commander." })}><MoreHorizontal size={18} /></button>
              </div>
              <div className="watchlist-list">
                {filteredIncidents.slice(0, 3).map((incident) => <IncidentRow key={incident.id} incident={incident} selected={selectedId === incident.id} onSelect={() => setSelectedId(incident.id)} />)}
                {filteredIncidents.length === 0 && <div className="empty-state"><Search size={20} /><span>No incidents match “{query}”</span></div>}
              </div>
              <button className="view-all" onClick={() => activateNav("Incidents")}>View full incident queue <ArrowUpRight size={15} /></button>
            </div>
          </section>

          <section className="detail-grid">
            <div className="incident-detail panel-card">
              <div className="detail-heading">
                <div><div className="section-kicker">SELECTED INCIDENT</div><div className="detail-id-row"><h2>{selectedIncident.id}</h2><span className={`priority ${selectedIncident.priority.toLowerCase()}`}>{selectedIncident.priority}</span><span className="state-chip"><StatusDot tone={selectedIncident.tone} />{selectedIncident.state}</span></div></div>
                <button className="more-button icon-only" onClick={() => toast("Incident actions", { description: "Assign, escalate, or create a problem record from this menu." })}><MoreHorizontal size={18} /></button>
              </div>
              <div className="detail-body">
                <div className="detail-summary"><h3>{selectedIncident.title}</h3><p>Customer impact detected by synthetic monitoring. 18% of EU checkout requests are failing and the error rate is trending upward.</p></div>
                <div className="detail-grid-meta"><div><span>ASSIGNMENT GROUP</span><strong>Payments Platform</strong></div><div><span>BUSINESS SERVICE</span><strong>{selectedIncident.service}</strong></div><div><span>OPENED</span><strong>02 Sep · 11:48</strong></div><div><span>CONTACT</span><strong>Major incident channel</strong></div></div>
                <div className="sla-block"><div className="sla-label-row"><div><span className="section-kicker">RESPONSE SLA</span><strong>Time to breach</strong></div><strong className={selectedIncident.sla > 75 ? "critical-text" : "warning-text"}>{scenarioMode ? "09m 18s" : "14m 32s"}</strong></div><div className="progress-track"><span style={{ width: `${scenarioMode ? 91 : selectedIncident.sla}%` }} /></div><div className="sla-caption"><span>Started 26m ago</span><span>Target: 60m</span></div></div>
              </div>
              <div className="detail-actions"><button className="primary-button small" onClick={promoteIncident}><Radar size={15} />Trigger major incident comms</button><button className="secondary-button" onClick={() => toast.success("Runbook attached", { description: "KB0010021 · Checkout API recovery runbook is now linked." })}><FileText size={15} />Attach runbook</button><button className="icon-button subtle" onClick={() => toast("Incident copied to clipboard") } aria-label="Copy incident"><Command size={16} /></button></div>
            </div>

            <div className="timeline-card panel-card">
              <div className="panel-heading"><div><div className="section-kicker">AUDIT TRAIL</div><h2>Control loop</h2></div><span className="secure-label"><LockKeyhole size={13} />Audited</span></div>
              <div className="timeline">
                <div className="timeline-item complete"><div className="timeline-icon"><CheckCircle2 size={15} /></div><div><strong>Monitoring signal correlated</strong><span>Automated · 11:48</span></div></div>
                <div className="timeline-item complete"><div className="timeline-icon"><UserRound size={15} /></div><div><strong>Assigned to Payments Platform</strong><span>Rule: service ownership · 11:50</span></div></div>
                <div className="timeline-item current"><div className="timeline-icon"><Wrench size={15} /></div><div><strong>Investigation in progress</strong><span>N. Patel · 12:04</span></div></div>
                <div className="timeline-item next"><div className="timeline-icon"><MessageSquareText size={15} /></div><div><strong>Stakeholder update due</strong><span>Recommended next action · 12:14</span></div></div>
              </div>
              <div className="timeline-note"><Sparkles size={15} /><p><strong>Automation insight:</strong> A major incident rule is ready because impact, error rate, and service criticality crossed the escalation threshold.</p></div>
            </div>
          </section>

          <section className="proof-strip">
            <div className="proof-intro"><div className="eyebrow dark">WHY THIS PROJECT SIGNALS READINESS</div><h2>Designed like a platform owner.</h2><p>This is not a ticket table. It is a compact demonstration of how workflow, data, automation, and communication fit together in ServiceNow.</p></div>
            <div className="proof-items"><div className="proof-item"><span className="proof-number">01</span><div><strong>Incident lifecycle</strong><span>Prioritization → assignment → resolution</span></div></div><div className="proof-item"><span className="proof-number">02</span><div><strong>SLA intelligence</strong><span>Risk surfaced before the breach</span></div></div><div className="proof-item"><span className="proof-number">03</span><div><strong>Automation design</strong><span>Rules turn signals into action</span></div></div><div className="proof-item"><span className="proof-number">04</span><div><strong>Auditability</strong><span>Every handoff leaves a trail</span></div></div></div>
            <button className="case-study-button" onClick={() => setShowNotes(true)}><BriefcaseBusiness size={16} />Read the case study <ArrowUpRight size={15} /></button>
          </section>

          <footer className="page-footer"><span><span className="footer-pulse" />ServiceNow-inspired portfolio project · Built for demonstration</span><span>Next build: CMDB dependency graph <ArrowUpRight size={13} /></span></footer>
        </div>
      </main>

      {showNotes && <div className="modal-backdrop" onClick={() => setShowNotes(false)}><section className="notes-modal" onClick={(event) => event.stopPropagation()}><div className="notes-modal-head"><div><div className="section-kicker">PROJECT CASE STUDY</div><h2>ServiceNow Ops Studio</h2></div><button className="icon-button subtle" onClick={() => setShowNotes(false)} aria-label="Close case study"><X size={18} /></button></div><div className="notes-scroll"><p className="notes-lede">A portfolio project that shows the full ITSM thinking loop: detect the signal, protect the SLA, route the work, and make the next action obvious.</p><div className="notes-section"><span className="notes-index">01</span><div><h3>The problem</h3><p>Operations teams do not need another list of tickets. They need a shared control plane that makes priority, ownership, customer impact, and time-to-breach legible in one glance.</p></div></div><div className="notes-section"><span className="notes-index">02</span><div><h3>ServiceNow capability map</h3><div className="capability-list"><div><strong>Incident Management</strong><span>Priority model, assignment group, state transitions, major incident path.</span></div><div><strong>Service Level Management</strong><span>Response clock, breach risk, target visibility, escalation threshold.</span></div><div><strong>Flow Designer</strong><span>Correlate signal → create incident → route owner → notify stakeholders.</span></div><div><strong>Knowledge Management</strong><span>Attach recovery runbooks at the moment of need.</span></div></div></div></div><div className="notes-section"><span className="notes-index">03</span><div><h3>What I would build in a real instance</h3><p>Custom incident workspace with UI Builder, Flow Designer subflows for P1 escalation, Performance Analytics indicators for response and resolution, and a CMDB relationship view for blast-radius analysis.</p></div></div><div className="notes-footer"><CheckCircle2 size={17} /><span>Built to be discussed in an interview: the UI is the entry point, the workflow decisions are the real project.</span></div></div></section></div>}

      {commandOpen && <div className="modal-backdrop command-backdrop" onClick={() => setCommandOpen(false)}><section className="command-modal" onClick={(event) => event.stopPropagation()}><div className="command-head"><Search size={17} /><input autoFocus placeholder="Search incidents, services, knowledge..." value={query} onChange={(event) => setQuery(event.target.value)} /><kbd>ESC</kbd></div><div className="command-results"><div className="command-label">QUICK ACTIONS</div><button onClick={() => { setCommandOpen(false); runScenario(); }}><Play size={15} /><span>Run live scenario</span><kbd>↵</kbd></button><button onClick={() => { setCommandOpen(false); setShowNotes(true); }}><FileText size={15} /><span>Open project case study</span></button><div className="command-label results-label">INCIDENTS</div>{filteredIncidents.map((incident) => <button key={incident.id} onClick={() => { setSelectedId(incident.id); setCommandOpen(false); }}><StatusDot tone={incident.tone} /><span><strong>{incident.id}</strong> {incident.title}</span><ChevronRight size={14} /></button>)}{filteredIncidents.length === 0 && <div className="command-empty">No results found. Try “checkout” or “VPN”.</div>}</div></section></div>}
    </div>
  );
}
